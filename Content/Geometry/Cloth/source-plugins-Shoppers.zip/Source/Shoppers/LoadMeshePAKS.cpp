// Fill out your copyright notice in the Description page of Project Settings.


#include "LoadMeshePAKS.h"



// Fill out your copyright notice in the Description page of Project Settings.

// Sets default values
//#define print(text) if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 1.5, FColor::White,text)

ALoadMeshePAKS::ALoadMeshePAKS()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ALoadMeshePAKS::BeginPlay()
{
	Super::BeginPlay();
	//DisplayPakFiles();
}

// Called every frame
void ALoadMeshePAKS::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

//USkeletalMesh * ALoadMeshePAKS::DisplayPakFiles() {
//	FPakPlatformFile *PakPlatformFile;
//	FString PlatformFileName = FPlatformFileManager::Get().GetPlatformFile().GetName();
//	/*if (GEngine)
//		GEngine->AddOnScreenDebugMessage(-1, 1.5, FColor::White, text)*/
//
//	UE_LOG(LogTemp, Warning, TEXT("@asd %s"), *PlatformFileName);
//	//print(TEXT("asd %s"), *PlatformFileName);
//	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("@asd %s"), *PlatformFileName));
//	if (PlatformFileName.Equals(FString(TEXT("PakFile"))))
//	{
//		PakPlatformFile = static_cast<FPakPlatformFile*>(&FPlatformFileManager::Get().GetPlatformFile());
//	}
//	else
//	{
//		PakPlatformFile = new FPakPlatformFile;
//		if (!PakPlatformFile->Initialize(&FPlatformFileManager::Get().GetPlatformFile(), TEXT("")))
//		{
//			UE_LOG(LogTemp, Error, TEXT("FPakPlatformFile failed to initialize"));
//			//print(TEXT("FPakPlatformFile failed to initialize"));
//			if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("FPakPlatformFile failed to initialize")));
//
//			return nullptr;
//		}
//		FPlatformFileManager::Get().SetPlatformFile(*PakPlatformFile);
//	}
//	TArray<FString> ArrAllMountedPakFile;
//	PakPlatformFile->GetMountedPakFilenames(ArrAllMountedPakFile);
//	UE_LOG(LogTemp, Warning, TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num());
//	//print(TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num());
//	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num()));
//
//	for (int32 i = 0; i < ArrAllMountedPakFile.Num(); i++)
//	{
//		FString PakFileName = ArrAllMountedPakFile[i];
//		UE_LOG(LogTemp, Warning, TEXT("PakFileName: %s"), *PakFileName);
//		//print(TEXT("PakFileName: %s"), *PakFileName);
//		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("PakFileName: %s"), *PakFileName));
//
//		FString PakFilePathFull = FPaths::ConvertRelativePathToFull(PakFileName);
//		FPakFile PakFile(PakPlatformFile, *PakFilePathFull, false);
//		TArray<FString> FileList;
//		FString MountPoint = PakFile.GetMountPoint();
//		PakFile.FindFilesAtPath(FileList, *MountPoint, true, false, true);
//		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("FindFilesAtPath: %d"), FileList.Num()));
//
//		for (int32 j = 0; j < FileList.Num(); j++)
//		{
//			FString AssetName = FileList[j];
//			FString AssetShortName = FPackageName::GetShortName(AssetName);
//			if (AssetName.Contains("Avatar") || AssetShortName.Contains("Avatar")) {
//				if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("AssetName: %s"), *AssetName));
//				if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("AssetShortName: %s"), *AssetShortName));
//
//				FString FileName, FileExt;
//				AssetShortName.Split(TEXT("."), &FileName, &FileExt);
//				FString NewAssetName = TEXT("/Game/") + FileName + TEXT(".") + FileName;
//
//				FSoftObjectPath StrNewAssetRef = NewAssetName;
//				FStreamableManager AssetLoader;
//				UObject* NewLoadedObject = AssetLoader.LoadSynchronous(StrNewAssetRef);
//				if (NewLoadedObject)
//				{
//					if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("Success")));
//
//					// do something, cast to compatible type.
//					return (USkeletalMesh *)NewLoadedObject;
//				}
//				else {
//					if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("Fail")));
//
//				}
//			}
//		}
//	}
//	return (USkeletalMesh *)nullptr;
//
//}
TArray<USkeletalMesh *> ALoadMeshePAKS::GetClothMeshes() {
	TArray<USkeletalMesh *> outClothMeshArray = TArray<USkeletalMesh *>();
	FPakPlatformFile *PakPlatformFile;
	FString PlatformFileName = FPlatformFileManager::Get().GetPlatformFile().GetName();
	/*if (GEngine)
		GEngine->AddOnScreenDebugMessage(-1, 1.5, FColor::White, text)*/

	UE_LOG(LogTemp, Warning, TEXT("@asd %s"), *PlatformFileName);
	//print(TEXT("asd %s"), *PlatformFileName);
	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("@asd %s"), *PlatformFileName));
	if (PlatformFileName.Equals(FString(TEXT("PakFile"))))
	{
		PakPlatformFile = static_cast<FPakPlatformFile*>(&FPlatformFileManager::Get().GetPlatformFile());
	}
	else
	{
		PakPlatformFile = new FPakPlatformFile;
		if (!PakPlatformFile->Initialize(&FPlatformFileManager::Get().GetPlatformFile(), TEXT("")))
		{
			UE_LOG(LogTemp, Error, TEXT("FPakPlatformFile failed to initialize"));
			//print(TEXT("FPakPlatformFile failed to initialize"));
			if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("FPakPlatformFile failed to initialize")));

			//return 0;
		}
		FPlatformFileManager::Get().SetPlatformFile(*PakPlatformFile);
	}
	TArray<FString> ArrAllMountedPakFile;
	PakPlatformFile->GetMountedPakFilenames(ArrAllMountedPakFile);
	UE_LOG(LogTemp, Warning, TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num());
	//print(TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num());
	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num()));

	for (int32 i = 0; i < ArrAllMountedPakFile.Num(); i++)
	{
		FString PakFileName = ArrAllMountedPakFile[i];
		UE_LOG(LogTemp, Warning, TEXT("PakFileName: %s"), *PakFileName);
		//print(TEXT("PakFileName: %s"), *PakFileName);
		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("PakFileName: %s"), *PakFileName));

		FString PakFilePathFull = FPaths::ConvertRelativePathToFull(PakFileName);
		FPakFile PakFile(PakPlatformFile, *PakFilePathFull, false);
		TArray<FString> FileList;
		FString MountPoint = PakFile.GetMountPoint();
		PakFile.FindFilesAtPath(FileList, *MountPoint, true, false, true);
		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("FindFilesAtPath: %d"), FileList.Num()));

		for (int32 j = 0; j < FileList.Num(); j++)
		{
			FString AssetName = FileList[j];
			FString AssetShortName = FPackageName::GetShortName(AssetName);
			if (AssetShortName.Contains("RUNTIMECLMODEL")) {
				if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("AssetName: %s"), *AssetName));
				if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("AssetShortName: %s"), *AssetShortName));

				FString FileName, FileExt;
				AssetShortName.Split(TEXT("."), &FileName, &FileExt);
				if (FileExt.Contains("uexp")) {
					continue;
				}
				FString NewAssetName = TEXT("/Game/AvatarMale/") + FileName + TEXT(".") + FileName;

				FSoftObjectPath StrNewAssetRef = NewAssetName;
				FStreamableManager AssetLoader;
				UObject* NewLoadedObject = AssetLoader.LoadSynchronous(StrNewAssetRef);
				if (NewLoadedObject)
				{
					if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("Success")));

					// do something, cast to compatible type.
					//return (USkeletalMesh *)NewLoadedObject;

					outClothMeshArray.Add((USkeletalMesh *)NewLoadedObject);

				}
				else {
					if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("Fail")));

				}
			}
		}
	}
	return outClothMeshArray;

}

TArray<USkeletalMesh *> ALoadMeshePAKS::GetAvatarMeshes() {
	TArray<USkeletalMesh *> outAvatarMeshArray = TArray<USkeletalMesh *>();
	FPakPlatformFile *PakPlatformFile;
	FString PlatformFileName = FPlatformFileManager::Get().GetPlatformFile().GetName();
	/*if (GEngine)
		GEngine->AddOnScreenDebugMessage(-1, 1.5, FColor::White, text)*/

	UE_LOG(LogTemp, Warning, TEXT("@asd %s"), *PlatformFileName);
	//print(TEXT("asd %s"), *PlatformFileName);
	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("@asd %s"), *PlatformFileName));
	if (PlatformFileName.Equals(FString(TEXT("PakFile"))))
	{
		PakPlatformFile = static_cast<FPakPlatformFile*>(&FPlatformFileManager::Get().GetPlatformFile());
	}
	else
	{
		PakPlatformFile = new FPakPlatformFile;
		if (!PakPlatformFile->Initialize(&FPlatformFileManager::Get().GetPlatformFile(), TEXT("")))
		{
			UE_LOG(LogTemp, Error, TEXT("FPakPlatformFile failed to initialize"));
			//print(TEXT("FPakPlatformFile failed to initialize"));
			if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("FPakPlatformFile failed to initialize")));

			//return 0;
		}
		FPlatformFileManager::Get().SetPlatformFile(*PakPlatformFile);
	}
	TArray<FString> ArrAllMountedPakFile;
	PakPlatformFile->GetMountedPakFilenames(ArrAllMountedPakFile);
	UE_LOG(LogTemp, Warning, TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num());
	//print(TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num());
	if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("ArrAllMountedPakFile: %d"), ArrAllMountedPakFile.Num()));

	for (int32 i = 0; i < ArrAllMountedPakFile.Num(); i++)
	{
		FString PakFileName = ArrAllMountedPakFile[i];
		UE_LOG(LogTemp, Warning, TEXT("PakFileName: %s"), *PakFileName);
		//print(TEXT("PakFileName: %s"), *PakFileName);
		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("PakFileName: %s"), *PakFileName));

		FString PakFilePathFull = FPaths::ConvertRelativePathToFull(PakFileName);
		FPakFile PakFile(PakPlatformFile, *PakFilePathFull, false);
		TArray<FString> FileList;
		FString MountPoint = PakFile.GetMountPoint();
		PakFile.FindFilesAtPath(FileList, *MountPoint, true, false, true);
		if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("FindFilesAtPath: %d"), FileList.Num()));

		for (int32 j = 0; j < FileList.Num(); j++)
		{
			FString AssetName = FileList[j];
			FString AssetShortName = FPackageName::GetShortName(AssetName);
			if ( AssetShortName.Contains("RUNTIMEAVMODEL")) {
				if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("AssetName: %s"), *AssetName));
				if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("AssetShortName: %s"), *AssetShortName));

				FString FileName, FileExt;
				AssetShortName.Split(TEXT("."), &FileName, &FileExt);
				if (FileExt.Contains("uexp")) {
					continue;
				}
				FString NewAssetName = TEXT("/Game/AvatarMale/") + FileName + TEXT(".") + FileName;

				FSoftObjectPath StrNewAssetRef = NewAssetName;
				FStreamableManager AssetLoader;
				UObject* NewLoadedObject = AssetLoader.LoadSynchronous(StrNewAssetRef);
				if (NewLoadedObject)
				{
					if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("Success")));

					// do something, cast to compatible type.
					//return (USkeletalMesh *)NewLoadedObject;

					outAvatarMeshArray.Add((USkeletalMesh *)NewLoadedObject);

				}
				else {
					if (GEngine) GEngine->AddOnScreenDebugMessage(-1, 10, FColor::White, FString::Printf(TEXT("Fail")));

				}
			}
		}
	}
	return outAvatarMeshArray;

}
