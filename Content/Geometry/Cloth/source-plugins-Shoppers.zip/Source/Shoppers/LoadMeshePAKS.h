// Fill out your copyright notice in the Description page of Project Settings.

#pragma once



#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "IPlatformFilePak.h"
#include "HAL/PlatformFilemanager.h"
#include "Misc/PackageName.h"
#include "Engine/StreamableManager.h"
#include "Engine/Engine.h"
#include "Engine/SkeletalMesh.h"

#include "LoadMeshePAKS.generated.h"

UCLASS()
class SHOPPERS_API ALoadMeshePAKS : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ALoadMeshePAKS();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	/*UFUNCTION(BlueprintCallable, Category = "LoadMeshePAKS")
		USkeletalMesh * DisplayPakFiles();*/
	UFUNCTION(BlueprintCallable, Category = "PakMeshLoader")
		TArray<USkeletalMesh*> GetAvatarMeshes();

	UFUNCTION(BlueprintCallable, Category = "PakMeshLoader")
		TArray<USkeletalMesh*> GetClothMeshes();

};