# RuntimeMeshLoader
RuntimeMeshLoader for UE4  
  
Use this plugin with ProceduralMeshComponent, you can load mesh with Blueprint in runtime,support relative and absolute Path.  

Supported file formats  
3DS  
BLEND (Blender)  
DAE/Collada  
FBX  
IFC-STEP  
ASE  
DXF  
HMP  
MD2  
MD3  
MD5  
MDC  
MDL  
NFF  
PLY  
STL  
X  
OBJ  
OpenGEX  
SMD  
LWO  
LXO  
LWS  
TER  
AC3D  
MS3D  
COB  
Q3BSP  
XGL  
CSM  
BVH  
B3D  
NDO  
Ogre Binary  
Ogre XML  
Q3D  
ASSBIN (Assimp custom format)  
glTF (partial)  
3MF  
