#include "VirtualMirrorPluginPrivatePCH.h"
#include "IVirtualMirrorPlugin.h"
#include "KinectAnimInstance.h"


UKinectAnimInstance::UKinectAnimInstance(const class FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	

}