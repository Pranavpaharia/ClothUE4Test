#include "VirtualMirrorPluginPrivatePCH.h"
#include "IVirtualMirrorPlugin.h"
#include "KinectV1AnimInstance.h"
#include "KinectV1Device.h"


UKinectV1AnimInstance::UKinectV1AnimInstance(const class FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	
	KinectV1Device = IVirtualMirrorPlugin::GetKinectV1DeviceSafe();
}

FVector UKinectV1AnimInstance::GetBonePosition(EJointType JointType) {
	if (!KinectV1Device) return FVector::ZeroVector;

	FVector PositionKinect = KinectV1Device->GetBonePosition(JointType);
	FVector PositionUE4 = FVector(PositionKinect.X, -PositionKinect.Z, PositionKinect.Y) / 10;
	return PositionUE4;
}

FRotator UKinectV1AnimInstance::GetBoneRotation(EJointType JointType) {
	if (!KinectV1Device) return FRotator::ZeroRotator;

	return KinectV1Device->GetBoneRotation(JointType);
}

float UKinectV1AnimInstance::GetSensorAngle() {
	if (!KinectV1Device) return 0;
	return KinectV1Device->SensorAngle;
}



