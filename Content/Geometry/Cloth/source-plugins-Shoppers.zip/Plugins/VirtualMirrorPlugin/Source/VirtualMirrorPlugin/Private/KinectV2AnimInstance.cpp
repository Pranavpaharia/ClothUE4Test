#include "VirtualMirrorPluginPrivatePCH.h"
#include "IVirtualMirrorPlugin.h"
#include "KinectV2AnimInstance.h"
#include "KinectV2Device.h"

UKinectV2AnimInstance::UKinectV2AnimInstance(const class FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
{
	
	KinectV2Device = IVirtualMirrorPlugin::GetKinectV2DeviceSafe();
}

FVector UKinectV2AnimInstance::GetBonePosition(EJointType JointType) {
	if (!KinectV2Device) return FVector::ZeroVector;
	FVector PositionKinect = KinectV2Device->GetBonePosition(JointType);
	FVector PositionUE4 = FVector(PositionKinect.X, -PositionKinect.Z, PositionKinect.Y) / 10;
	return PositionUE4;
}

FRotator UKinectV2AnimInstance::GetBoneRotation(EJointType JointType) {
	if (!KinectV2Device) return FRotator::ZeroRotator;
	return KinectV2Device->GetBoneRotation(JointType);
}

float UKinectV2AnimInstance::GetSensorAngle() {
	if (!KinectV2Device) return 0;
	return KinectV2Device->SensorAngle;
}

